package com.example.static_features

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import okhttp3.FormBody
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var responseTextView: TextView
    private lateinit var adapter: AppAdapter
    private lateinit var apkSpinner: Spinner
    private lateinit var selectButton: Button

    private lateinit var installedApps: List<ApplicationInfo>

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        responseTextView = findViewById(R.id.responseTextView)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AppAdapter()
        recyclerView.adapter = adapter

        apkSpinner = findViewById(R.id.apkSpinner)
        selectButton = findViewById(R.id.selectButton)

        selectButton.setOnClickListener { displaySelectedAppFeatures() }

        retrieveInstalledApps()
        populateSpinner()
        displaySelectedAppFeatures()
    }

    private fun retrieveInstalledApps() {
        val packageManager: PackageManager = packageManager
        installedApps = packageManager.getInstalledApplications(
            PackageManager.GET_META_DATA or PackageManager.GET_ACTIVITIES
        )
    }

    private fun populateSpinner() {
        val apkNames = installedApps.map { it.loadLabel(packageManager).toString() }
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            apkNames
        )
        apkSpinner.adapter = adapter
    }

    private fun displaySelectedAppFeatures() {
        val selectedApkName = apkSpinner.selectedItem.toString()
        val selectedAppInfo = installedApps.find { it.loadLabel(packageManager).toString() == selectedApkName }

        selectedAppInfo?.let {
            val packageName = selectedAppInfo.packageName
            val appName = selectedAppInfo.loadLabel(packageManager).toString()
            val appInfo: ApplicationInfo = packageManager.getApplicationInfo(
                packageName,
                PackageManager.GET_META_DATA
            )

            val statsData = LinkedHashMap<String, String>()
//            statsData["packageName"] = packageName
//            statsData["appName"] = appName
//            statsData["targetSdkVersion"] = appInfo.targetSdkVersion.toString()
//            statsData["UID"] = appInfo.uid.toString()
//            statsData["NativeLibraryDirectory"] = appInfo.nativeLibraryDir
//            statsData["TaskAffinity"] = appInfo.taskAffinity
//            statsData["MinSdkVersion"] = appInfo.minSdkVersion.toString()
//            statsData["IsSystemApp"] = isSystemApp(appInfo).toString()
//            statsData["IsDebuggable"] = isDebuggable(appInfo).toString()
            statsData["APICall"] = getApiCall()
            statsData["Permission"] = getPermission()
            statsData["URL"] = getUrl()
            statsData["Provider"] = getProvider()
            statsData["Feature"] = getFeature()
            statsData["Intent"] = getIntent().toString()
            statsData["Activity"] = getActivity()
            statsData["Call"] = getCall()
            statsData["ServiceReceiver"] = getServiceReceiver()
            statsData["RealPermission"] = getRealPermission()

            val gson = Gson()
            val json = gson.toJson(statsData)

            val requestBody = FormBody.Builder()
                .add("stringToAppend", json)
                .build()

            val client = OkHttpClient()
            val request = Request.Builder()
                .url("http://172.168.1.18:8000")
                .post(requestBody)
                .build()


            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    // Handle failure
                    runOnUiThread {
                        Toast.makeText(
                            applicationContext,
                            "Request failed: ${e.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    // Handle success or failure based on response code
                    runOnUiThread {
                        if (response.isSuccessful) {
                            val responseData = response.body?.string()
                            responseTextView.text = responseData
                            responseTextView.visibility = View.VISIBLE
                            Toast.makeText(
                                applicationContext,
                                "Data appended successfully",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                applicationContext,
                                "Failed to append data: ${response.code}",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            })
        }
    }

    private fun isSystemApp(appInfo: ApplicationInfo): Boolean {
        return appInfo.flags and ApplicationInfo.FLAG_SYSTEM != 0
    }

    private fun isDebuggable(appInfo: ApplicationInfo): Boolean {
        return appInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0
    }
    private fun getPermission(): String {
        // Implement your logic to get the permission information
        // For example, you can retrieve the list of permissions from the app's manifest file
        val selectedApkName = apkSpinner.selectedItem.toString()
        val selectedAppInfo = installedApps.find { it.loadLabel(packageManager).toString() == selectedApkName }

        selectedAppInfo?.let {
            val packageName = selectedAppInfo.packageName
            val packageInfo = packageManager.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
            val permissions = packageInfo.requestedPermissions
            return permissions?.joinToString("\n") ?: "No permissions found"
        }
        return "Permission information not available"
    }

    private fun getUrl(): String {
        // Implement your logic to get the URL information
        // For example, you can retrieve the URL from the app's metadata
        val selectedApkName = apkSpinner.selectedItem.toString()
        val selectedAppInfo = installedApps.find { it.loadLabel(packageManager).toString() == selectedApkName }

        selectedAppInfo?.let {
            val packageName = selectedAppInfo.packageName
            val appInfo = packageManager.getApplicationInfo(packageName, PackageManager.GET_META_DATA)
            val url = appInfo.metaData?.getString("url")
            return url ?: "URL not found"
        }
        return "URL information not available"
    }

    private fun getProvider(): String {
        // Implement your logic to get the provider information
        // For example, you can retrieve the list of content providers from the app's manifest file
        val selectedApkName = apkSpinner.selectedItem.toString()
        val selectedAppInfo = installedApps.find { it.loadLabel(packageManager).toString() == selectedApkName }

        selectedAppInfo?.let {
            val packageName = selectedAppInfo.packageName
            val packageInfo = packageManager.getPackageInfo(packageName, PackageManager.GET_PROVIDERS)
            val providers = packageInfo.providers
            return providers?.joinToString("\n") ?: "No providers found"
        }
        return "Provider information not available"
    }

    private fun getFeature(): String {
        // Implement your logic to get the feature information
        // For example, you can retrieve the list of features from the app's manifest file
        val selectedApkName = apkSpinner.selectedItem.toString()
        val selectedAppInfo = installedApps.find { it.loadLabel(packageManager).toString() == selectedApkName }

        selectedAppInfo?.let {
            val packageName = selectedAppInfo.packageName
            val packageInfo = packageManager.getPackageInfo(packageName, PackageManager.GET_CONFIGURATIONS)
            val features = packageInfo.reqFeatures
            return features?.joinToString("\n") ?: "No features found"
        }
        return "Feature information not available"
    }

    private fun getActivity(): String {
        // Implement your logic to get the activity information
        // For example, you can retrieve the list of activities from the app's manifest file
        val selectedApkName = apkSpinner.selectedItem.toString()
        val selectedAppInfo = installedApps.find { it.loadLabel(packageManager).toString() == selectedApkName }

        selectedAppInfo?.let {
            val packageName = selectedAppInfo.packageName
            val packageInfo = packageManager.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES)
            val activities = packageInfo.activities
            return activities?.joinToString("\n") ?: "No activities found"
        }
        return "Activity information not available"
    }

    private fun getCall(): String {
        // Implement your logic to get the call information
        // For example, you can retrieve the list of call permissions from the app's manifest file
        val selectedApkName = apkSpinner.selectedItem.toString()
        val selectedAppInfo = installedApps.find { it.loadLabel(packageManager).toString() == selectedApkName }

        selectedAppInfo?.let {
            val packageName = selectedAppInfo.packageName
            val packageInfo = packageManager.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
            val permissions = packageInfo.requestedPermissions
            val callPermissions = permissions?.filter { it.startsWith("android.permission.CALL") }
            return callPermissions?.joinToString("\n") ?: "No call permissions found"
        }
        return "Call information not available"
    }

    private fun getApiCall(): String {
        // Assuming you have a list of API calls stored in a variable called "apiCalls"
        val apiCalls = listOf(
            "GET /api/users",
            "POST /api/login",
            "PUT /api/users/1",
            "DELETE /api/users/1"
        )
        // Concatenate the API call information into a single string
        return apiCalls.joinToString("\n")
    }


    private fun getServiceReceiver(): String {
        // Implement your logic to get the service receiver information
        // For example, you can retrieve the list of service receivers from the app's manifest file
        val selectedApkName = apkSpinner.selectedItem.toString()
        val selectedAppInfo = installedApps.find { it.loadLabel(packageManager).toString() == selectedApkName }

        selectedAppInfo?.let {
            val packageName = selectedAppInfo.packageName
            val packageInfo = packageManager.getPackageInfo(packageName, PackageManager.GET_RECEIVERS)
            val receivers = packageInfo.receivers
            return receivers?.joinToString("\n") ?: "No service receivers found"
        }
        return "Service receiver information not available"
    }

    private fun getRealPermission(): String {
        // Implement your logic to get the real permission information
        // This can vary depending on your requirements
        return "Real permission information"
    }

    inner class AppAdapter : RecyclerView.Adapter<AppViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(
                R.layout.app_item_layout,
                parent,
                false
            )
            return AppViewHolder(view)
        }

        override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
            val appInfo = installedApps[position]
            val appName = appInfo.loadLabel(packageManager).toString()
            holder.appNameTextView.text = appName
        }

        override fun getItemCount(): Int {
            return installedApps.size
        }
    }

    inner class AppViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val appNameTextView: TextView = itemView.findViewById(R.id.appNameTextView)
    }
}